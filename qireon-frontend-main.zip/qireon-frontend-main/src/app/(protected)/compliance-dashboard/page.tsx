import GapAssessmentReport from '@/component/dashboard/GapAssessmentReport '
import React from 'react'

const page = () => {
    return (
        <div>
            <GapAssessmentReport />
        </div>
    )
}

export default page
