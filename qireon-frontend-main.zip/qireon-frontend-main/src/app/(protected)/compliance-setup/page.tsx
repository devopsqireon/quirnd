import ComplianceConfiguration from '@/component/dashboard/compliance-environment-config'
import React from 'react'

const page = () => {
    return (
        <div>
            <ComplianceConfiguration />
        </div>
    )
}

export default page
