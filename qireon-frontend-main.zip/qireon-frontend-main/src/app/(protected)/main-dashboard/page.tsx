import ComplianceDashboard from '@/component/dashboard/compliance-dashboard'
import React from 'react'

const page = () => {
    return (
        <div>
            <ComplianceDashboard />
        </div>
    )
}

export default page
