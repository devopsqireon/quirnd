// /app/awareness-training/components/display/index.ts
export { default as TrainingCard } from './TrainingCard';
export { default as AssignmentTable } from './AssignmentTable';
export { default as CompletionLogTable } from './CompletionLogTable';