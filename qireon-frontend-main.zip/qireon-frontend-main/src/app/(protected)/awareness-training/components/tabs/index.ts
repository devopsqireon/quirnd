// /app/awareness-training/components/tabs/index.ts
export { default as TrainingLibraryTab } from './TrainingLibraryTab';
export { default as AssignmentsTab } from './AssignmentsTab';
export { default as CompletionLogsTab } from './CompletionLogsTab';
export { default as ReportsTab } from './ReportsTab';