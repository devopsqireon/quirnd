// /app/awareness-training/components/reports/index.ts
export { default as MetricsOverview } from './MetricsOverview';
export { default as ReportsChartsSection } from './ReportsChartsSection';
export { default as ComplianceSection } from './ComplianceSection';
export { default as DepartmentMetricsTable } from './DepartmentMetricsTable';
