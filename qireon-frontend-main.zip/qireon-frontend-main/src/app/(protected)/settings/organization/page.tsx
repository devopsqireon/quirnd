// src/app/(protected)/settings/organization/page.tsx

import { OrganizationSettingsLayout } from "./components/organization/OrganizationSettingsLayout";

export default function OrganizationSettingsPage() {
  return <OrganizationSettingsLayout />;
}