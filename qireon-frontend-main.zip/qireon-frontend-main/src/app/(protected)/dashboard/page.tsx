import DashboardPage from '@/component/dashboard/home'
import React from 'react'

const page = () => {
    return (
        <div>
            <DashboardPage />
        </div>
    )
}

export default page
